from pathlib import Path
from .db_utils import run_query, DB_PATH
import os

class Employee:
    def __init__(self, employee_id, db_path=DB_PATH):
        self.employee_id = int(employee_id)
        self.db_path = db_path
        self._name = None
        self._load_name()

    def _load_name(self):
        print(f"DB exists? {self.db_path.exists()}, path: {self.db_path}")  # aici
        query = "SELECT first_name || ' ' || last_name FROM employee WHERE employee_id = ?"
        df = run_query(query, params=(self.employee_id,), db_path=self.db_path)
        self._name = df.iloc[0, 0] if not df.empty else "Unknown"

    @property
    def name(self):
        return self._name

    def model_data(self, _=None):
        query = """
        SELECT event_date, positive_events, negative_events
        FROM employee_events
        WHERE employee_id = ?
        ORDER BY event_date
        """
        return run_query(query, params=(self.employee_id,), db_path=self.db_path)

    def get_names(self, _=None):
        query = """
        SELECT employee_id, first_name || ' ' || last_name AS full_name
        FROM employee
        ORDER BY full_name
        """
        df = run_query(query, db_path=self.db_path)
        return df.values.tolist()

    def get_user_type_names_and_ids(self):
        query = "SELECT employee_id, first_name || ' ' || last_name AS name FROM employee ORDER BY name"
        df = run_query(query, db_path=self.db_path)
        return list(zip(df['name'], df['employee_id']))  # (label, value)
        
    def notes(self):
        query = """
        SELECT note_date, note
        FROM notes
        WHERE employee_id = ?
        ORDER BY note_date DESC
        """
        return run_query(query, params=(self.employee_id,), db_path=self.db_path)
